import React from 'react'
import './Footer.css'
const Footer = () => {
    return (
        <div className="footer">
            <p>Meals <span>App</span> 2021 &copy;</p>
        </div>
    )
}

export default Footer