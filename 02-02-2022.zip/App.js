import React from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer'; 
import Categories from './components/Categories';
import RandomMeal from './components/RandomMeal';
import HomePage from './components/HomePage';
import { Routes,Route} from 'react-router-dom'; 
function App() {
  return (
    <div className="App">
      <Routes>
      <Navbar />
      <Routes>
        <Route  path="/" element={<HomePage/>}/>
        <Route path="/categories" element={<Categories/>}/>
        <Route path="/random" element={<RandomMeal/>}/>
      </Routes>
      <Footer />
      </Routes>
    </div>
  );
}

export default App;